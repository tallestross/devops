# encoding: utf-8
BUILD_INFO = {"build_date"=>"2017-06-15T03:03:41Z", "build_sha"=>"76c4926f4da6fa4a5d1ec9f5e5770dd85a8b1958", "build_snapshot"=>false}